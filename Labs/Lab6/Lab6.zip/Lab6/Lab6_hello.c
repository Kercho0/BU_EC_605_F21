// Arnaud Harmange U13657431

#include <stdio.h>

int main(){
	printf("Hello EC605 from arnaudh!\n");
	return 0;
}