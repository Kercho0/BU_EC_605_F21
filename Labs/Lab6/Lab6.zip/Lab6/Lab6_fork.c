// Arnaud Harmange U13657431
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int fib (int n){
	if (n<= 1){
		return n;
	}
	return fib(n-1)+fib(n-2);
}

int count (){
	int num = 0;
	while(num<1000){
		if(num % 100 == 0){
			printf("%s %d %d \n","Parent pid", getpid() ,num);
		}
		num++;
	}
	return num;
}

int printeven(){
	int n = 11;
	int x;
	for(int i =0; n>0; i++){
		x=fib(i);
		if(x>1000000){
			break;
		}
		else if(x % 2==0){
			printf("%s %d %d \n","Child pid" , getpid(),x);
			n--;
		}
	}
	return 0;
}


int main(){
	int place;
	int number;
	pid_t c_pid = fork();

	if(c_pid == 0){
		place = printeven();
		exit(EXIT_SUCCESS);
	}
	else{
		wait(NULL);
		number = count();

	}
	return 0;
}
